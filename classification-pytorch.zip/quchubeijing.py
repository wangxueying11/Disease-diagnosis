import cv2
import os
import numpy as np
def sliding_window(image, window, step):
    for y in range(0, image.shape[0] - window[1], step):
        for x in range(0, image.shape[1] - window[0], step):
            yield (x,y, image[:,y:y + window[1], x:x + window[0]])
    #最后一列
    for y in range(0, image.shape[0] - window[1], step):
        yield (image.shape[1]-window[0],y, image[:,y:y + window[1],image.shape[1]-window[0]:image.shape[1]])
    #最后一行
    for x in range(0, image.shape[1] - window[0], step):
        yield (x,image.shape[0]-window[1], image[image.shape[0]-window[1]:image.shape[0],x:x+window[0]])
    #右下角
    yield (image.shape[1]-window[0],image.shape[0]-window[1], image[:,image.shape[0]-window[1]:image.shape[0],image.shape[1]-window[0]:image.shape[1]])
if __name__ == '__main__':
    #读取图片
    (window_w, window_h)= (500,500)
    i=0
    for fn in os.listdir(r'G:/wangxueying/fenlei/classification-pytorch/classification-pytorch-main/img/'): #文件读取路径
        image = cv2.imread('G:/wangxueying/fenlei/classification-pytorch/classification-pytorch-main/img/'+fn)
        height, width, channels = image.shape
        new_im = np.ones((height, width, 4)) * 255
        new_im[:, :, :3] = image
        img_name=os.path.splitext(fn)[0]
        for i in range(height):
            for j in range(width):
                if new_im[i, j, :3].tolist() == [255.0, 255.0, 255.0]:
                    new_im[i, j, :] = np.array([255.0, 255.0, 255.0, 0])
        for (x, y, window) in sliding_window(image, (window_w, window_h), 250):
            i=i+1#切割张数
            filename='cut'+str(i)+'.png'
            slice = new_im[y:y+window_h,x:x+ window_w]
            cv2.imwrite('G:/wangxueying/fenlei/classification-pytorch/classification-pytorch-main/cut/'+img_name+filename, slice) #保存图片



