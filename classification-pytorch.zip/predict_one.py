# '''
# predict.py有几个注意点
# 1、无法进行批量预测，如果想要批量预测，可以利用os.listdir()遍历文件夹，利用Image.open打开图片文件进行预测。
# 2、如果想要将预测结果保存成txt，可以利用open打开txt文件，使用write方法写入txt，可以参考一下txt_annotation.py文件。
# '''
from PIL import Image

from classification import Classification

classfication = Classification()

while True:
    img = input('Input image filename:')
    try:
        image = Image.open(img)
    except:
        print('Open Error! Try again!')
        continue
    else:
        class_name = classfication.detect_image(image)
        print(class_name)
# from PIL import Image
#
# from classification import Classification
# import os
# import numpy as np
# from tqdm import tqdm
# classfication = Classification()
# dir_origin_path= "img/"
# dir_save_path = "img_out/"
# a=[]
# img_names = os.listdir(dir_origin_path)
# for img_name in tqdm(img_names):
#     if img_name.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
#         image_path = os.path.join(dir_origin_path, img_name)
#         image = Image.open(image_path)
#         class_name = classfication.detect_image(image)
#         a.append(class_name)
#         if not os.path.exists(dir_save_path):
#             os.makedirs(dir_save_path)
#             class_name.save(os.path.join(dir_save_path, img_name.replace(".jpg", ".png")), quality=95, subsampling=0)
# print(a)

