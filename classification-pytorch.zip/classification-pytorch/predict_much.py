'''
predict.py有几个注意点
1、无法进行批量预测，如果想要批量预测，可以利用os.listdir()遍历文件夹，利用Image.open打开图片文件进行预测。
2、如果想要将预测结果保存成txt，可以利用open打开txt文件，使用write方法写入txt，可以参考一下txt_annotation.py文件。
'''
from PIL import Image
import matplotlib.pyplot as plt
from classification import Classification
import os
import numpy as np
from tqdm import tqdm
classfication = Classification()
dir_origin_path= "E:/fenlei/classification-pytorch/classification-pytorch-main/DATA/"
dir_save_path = "img_out/"
if not os.path.exists(dir_save_path):
    os.makedirs(dir_save_path)
a=[]
i = 0
img_names = os.listdir(dir_origin_path)
for img_name in tqdm(img_names):
    if img_name.lower().endswith(('.bmp', '.dib', '.png', '.jpg', '.jpeg', '.pbm', '.pgm', '.ppm', '.tif', '.tiff')):
        image_path = os.path.join(dir_origin_path, img_name)
        image = Image.open(image_path)
        class_name = classfication.detect_image(image)
        a.append(class_name)
        i = i + 1
        filename = "predict" + str(i) + '.jpg'
        plt.savefig(dir_save_path + filename)
        # plt.close("close")
        # plt.savefig(os.path.join(dir_save_path, img_name.replace(".jpg", ".png")), quality=95, subsampling=0)
print(a)
telophase='telophase'
medium ='medium'
infancy='infancy'
def classify(a):
    if telophase in a:
        print('晚期')
    else:
        if medium in a:
            print('中期')
        else:
            if infancy in a:
                print('初期')
            else:
                print('正常')
classify(a)











