# 谁的电脑#王雪莹
from PIL import Image
import matplotlib.pyplot as plt
from classification import Classification
import os
import cv2
import torch
import seaborn as sns
import numpy as np
from tqdm import tqdm
import sklearn.metrics
torch.cuda.current_device()
classfication = Classification()
dir_origin_path= "D:/wxy/classification-pytorch-main/cut/"#切割保存路径
dir_save_path = "img_out/" #切割图片分类结果路径
if not os.path.exists(dir_save_path):
    os.makedirs(dir_save_path)
b=[]
a=[]
name=[]
k  = 0
#定义切割函数
def sliding_window(image, window, step):
    for y in range(0, image.shape[0] - window[1], step):
        for x in range(0, image.shape[1] - window[0], step):
            yield (x,y, image[:,y:y + window[1], x:x + window[0]])
    #最后一列
    for y in range(0, image.shape[0] - window[1], step):
        yield (image.shape[1]-window[0],y, image[:,y:y + window[1],image.shape[1]-window[0]:image.shape[1]])
    #最后一行
    for x in range(0, image.shape[1] - window[0], step):
        yield (x,image.shape[0]-window[1], image[image.shape[0]-window[1]:image.shape[0],x:x+window[0]])
    #右下角
    yield (image.shape[1]-window[0],image.shape[0]-window[1], image[:,image.shape[0]-window[1]:image.shape[0],image.shape[1]-window[0]:image.shape[1]])
if __name__ == '__main__':
    #读取图片
    (window_w, window_h)= (600,600)
    i=L=0
    for fn in os.listdir(r'D:/wxy/classification-pytorch-main/100he/1/'): #文件读取路径（整叶
        L=L+1
        image = cv2.imread('D:/wxy/classification-pytorch-main/100he/1/'+fn)
        img_name=fn.split('_')[0]
        img_name_i=fn.split('.')[0]
        name.append(img_name) #原始病程列表
        for (x, y, window) in sliding_window(image, (window_w, window_h),600):
            i=i+1#切割张数
            filename_cut='cut'+str(i)+'.jpg'
            slice = image[y:y+window_h,x:x+ window_w] #img_name
            cv2.imwrite('D:/wxy/classification-pytorch-main/cut/'+img_name+filename_cut, slice) #保存图片路径
            img_split=Image.open('D:/wxy/classification-pytorch-main/cut/'+img_name+filename_cut)
            class_name = classfication.detect_image(img_split)
            a.append(class_name)
            # k = k + 1
            # filename_class = img_name_i + str(k) + '.jpg'
            # plt.savefig(dir_save_path + filename_class)
        print(a)
        Late='Late'
        Middle ='Middle'
        Early='Early'
        Normal='Normal'
        Background='Background'
        def classify(a):
            # wrong_name = '_wrong' + str(L) + '.jpg'
            if Late in a:
                b.append('Late')
                ind=Late
                if ind != img_name:
                    cv2.imwrite(
                        "D:/wxy/classification-pytorch-main/Wrong/" + img_name_i +'_'+'Late'+ '.jpg',image)
                if ind == img_name:
                    cv2.imwrite(
                        "D:/wxy/classification-pytorch-main/True/" + img_name_i +'.jpg',image)
                print('图片'+fn+'属于晚期')
            else:
                if Middle in a:
                    b.append('Middle')
                    ind = Middle
                    if ind != img_name:
                        cv2.imwrite(
                            "D:/wxy/classification-pytorch-main/Wrong/" + img_name_i +'_'+'Middle'+ '.jpg',image)
                    if ind == img_name:
                        cv2.imwrite(
                            "D:/wxy/classification-pytorch-main/True/" + img_name_i + '.jpg',image)
                    print('图片'+fn+'属于中期')
                else:
                    if Early in a:
                        b.append('Early')
                        ind = Early
                        if ind != img_name:
                            cv2.imwrite(
                                "D:/wxy/classification-pytorch-main/Wrong/" + img_name_i +'_'+'Early'+ '.jpg',image)
                        if ind == img_name:
                            cv2.imwrite(
                                "D:/wxy/classification-pytorch-main/True/" + img_name_i + '.jpg',image)
                        print('图片'+fn+'属于早期')
                    else:
                        if Normal in a:
                            b.append('Normal')
                            ind = Normal
                            if ind != img_name:
                                cv2.imwrite(
                                    "D:/wxy/classification-pytorch-main/Wrong/" + img_name_i +'_'+'Normal'+ '.jpg',image)
                            if ind == img_name:
                                cv2.imwrite(
                                    "D:/wxy/classification-pytorch-main/True/" + img_name_i + '.jpg',image)
                            print('图片'+fn+'属于正常')
                        else:
                            b.append('Background')
                            print('图片'+fn+'属于背景')

        classify(a)
        a = []
s=['Normal', 'Early', 'Middle', 'Late']
r = sklearn.metrics.confusion_matrix(name, b,labels=['Background','Normal', 'Early', 'Middle', 'Late'])
r = np.array(r[1:])[:, 1:].astype(float)
print(r)
sns.heatmap(r, cmap='Purples',annot=True,xticklabels=s,yticklabels=s) #画热力图,annot=True 代表 在图上显示 对应的值， fmt 属性 代表输出值的格式，cbar=False, 不显示 热力棒
plt.xlabel('Predicted Value')
plt.ylabel('True Value')
metrics_out_cut_path = "./metrics_out/metrics_out1"
if not os.path.exists(metrics_out_cut_path):
    os.makedirs(metrics_out_cut_path)
plt.savefig('./metrics_out/metrics_out1/metrics.jpg')
# plt.show()
FP = r.sum(axis=0) - np.diag(r)
FN = r.sum(axis=1) - np.diag(r)
TP = np.diag(r)
TN = r.sum() - (FP + FN + TP)
FP = FP.astype(float)
FN = FN.astype(float)
TP = TP.astype(float)
TN = TN.astype(float)
Precision=TP/(TP+FP)
Recall=TP/(TP+FN)
F1=(2*Precision*Recall)/(Precision+Recall)
accuracy=(TP+TN)/(TP+FN+FP+TN)
with open('D:/wxy/classification-pytorch-main/metrics_out/metrics_out1/data.txt', 'w') as f: # 设置文件对象data.txt
    print("TP值为：",file=f)
    print(TP,file = f)
    print("TN值为：",file=f)
    print(TN,file = f)
    print("FP值为：",file=f)
    print(FP,file = f)
    print("FN值为：",file=f)
    print(FN,file = f)
    print("Precision值为：",file=f)
    print(Precision, file=f)
    print("Recall值为：",file=f)
    print(Recall, file=f)
    print("F1值为：",file=f)
    print(F1, file=f)
    print("accuracy值为：",file=f)
    print(accuracy, file=f)
print('一共有'+str(L)+'张图片，其中:\n背景有'+str(b.count('Background'))+'张\n正常叶片有'+str(b.count('Normal'))+'张\n早期有'+str(b.count('Early'))+'张\n中期有'+str(b.count('Middle'))+'张\n晚期有'+str(b.count('Late'))+'张')