# 谁的电脑#王雪莹
# path='E:/fenlei/classification-pytorch/classification-pytorch-main/img/.jpg'
# save_path='E:/fenlei/classification-pytorch/classification-pytorch-main/img/.jpg'
from PIL import Image
import os.path
import glob


def convertjpg(jpgfile, outdir, width=3000, height=3000):  # 自行修改要修改的尺寸 800*450或400*350
    img = Image.open(jpgfile)
    try:
        new_img = img.resize((width, height), Image.BILINEAR)
        if new_img.mode == 'P':
            new_img = new_img.convert("RGB")
        if new_img.mode == 'RGBA':
            new_img = new_img.convert("RGB")
        new_img.save(os.path.join(outdir, os.path.basename(jpgfile)))
    except Exception as e:
        print(e)


for jpgfile in glob.glob("G:/wangxueying/fenlei/classification-pytorch/classification-pytorch-main/Leaf_Photo_rename/*.jpg"):  # “”里的部分自行改为自己的原图储存位置+/*.jpg
    # print(jpgfile)
    convertjpg(jpgfile, "G:/wangxueying/fenlei/classification-pytorch/classification-pytorch-main/Leaf_Photo_rename/")  # 改为自己的存储位置